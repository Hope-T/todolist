import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/*

Author: Hope Tsai
Date Completed: May 21, 2020
About: This is a simple to-do list program.
Intention: learning Java Swing, try/catch, reading and writing to files
 */
public class Main{

    public static void main(String[] args){
        JFrame f = new JFrame();
        f.setSize(300, 300);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel p = new JPanel();
        f.add(p);
        placeComponents(p);
        f.setVisible(true);
    }
    private static void placeComponents(JPanel p){
        p.setLayout(null);
        JLabel userLabel = new JLabel("User");
        userLabel.setBounds(10,20,80,25);
        p.add(userLabel);

        JTextField userText = new JTextField(25);
        userText.setBounds(100,20,165,25);
        p.add(userText);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(10,50,80,25);
        p.add(passwordLabel);

        JPasswordField passwordText = new JPasswordField(25);
        passwordText.setBounds(100,50,165,25);
        p.add(passwordText);

        JButton loginButton = new JButton("login");
        loginButton.setBounds(10,80,80,25);
        loginButton.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                JLabel noText;

                if(userText.getText().equals("")){
                    noText = new JLabel("please fill in both your username and password!");
                    noText.setBounds(10,100,400,25);
                    p.add(noText);
                    p.repaint();
                }
                else if(passwordText.getText().equals("")){
                    noText = new JLabel("please fill in both your username and password!");
                    noText.setBounds(10,100,400,25);
                    p.add(noText);
                    p.repaint();
                }
                else{
                    try {
                        todoPage(userText.getText(), passwordText.getText(), p);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }


            }
        });
        p.add(loginButton);

    }

    private static void todoPage(String username, String password, JPanel p) throws IOException {
        p.removeAll();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.validate();
        p.repaint();


        File users = new File("userList.txt");
        Scanner sc = new Scanner(users);

        boolean foundUser = false;
        boolean foundPassword = false;

        while (sc.hasNext()){
            if(sc.next().equals(username)){
                foundUser = true;

                  if(sc.next().equals(password)){
                    foundPassword = true;
                }
            }

            if(foundUser && foundPassword){
                break;
            }
        }
        sc.close();


        if(foundUser == false){
            JLabel createUser = new JLabel("No such username was found, so we have created an account for you with the provided password");
            createUser.setBounds(10,10,500,100);
            p.add(createUser);
            p.repaint();
            FileWriter myWriter = new FileWriter("userList.txt", true);
            myWriter.append(username + " " + password + "\r\n" );
            myWriter.close();

            populateList(p, username);

        }
        else if(foundPassword == false){
            JLabel noMatch = new JLabel("incorrect password!");
            p.add(noMatch);

            //option to try again
            JLabel tryAgain = new JLabel("Would you like to try again?");
            p.add(tryAgain);
            JButton yes = new JButton("yes");

            yes.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if("yes".equals(e.getActionCommand())){
                        p.removeAll();
                        p.validate();
                        p.repaint();
                        placeComponents(p);
                    }

                }
            });

            JButton no = new JButton("no");
            no.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if("no".equals(e.getActionCommand())) {
                        p.removeAll();
                        JLabel goodbye = new JLabel("Have a good day!");
                        p.add(goodbye);
                        p.validate();
                        p.repaint();
                    }

                }
            });

            p.add(yes);
            p.add(no);
            p.repaint();
            p.validate();
        }
        else{
           
          populateList(p, username);

        }





    }

    private static void populateList(JPanel p, String username) throws IOException{
        JLabel match = new JLabel("pulling up your todo list...");
        p.add(match);
        Scanner todos = null;

        try {
            File myFile = new File(username + ".txt");

            if (myFile.createNewFile()) {
                System.out.println("file created");
            }

            todos = new Scanner(myFile);
        }
        catch(IOException e){
            System.out.println("error");
        }


        JCheckBox tempHolder;

        while(todos.hasNextLine()) {
            int counter = 0;
            String item = todos.nextLine();
            boolean selected = false;

            if(item.substring(0,1).equals("1")) {
                selected = true;

            }

            tempHolder = new JCheckBox(item.substring(1), selected);
            tempHolder.addChangeListener(new ChangeListener() {
                @Override
                public void stateChanged(ChangeEvent changeEvent) {
                    JCheckBox cb = (JCheckBox) changeEvent.getSource();
                    File og = new File(username + ".txt");
                    Scanner sc = null;
                    try {
                        sc = new Scanner(og);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    FileWriter myFile = null;
                    try {
                        myFile = new FileWriter(username + "temp.txt", true);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    while (sc.hasNextLine()) {
                        String next = sc.nextLine();

                        if (cb.getText().equals(next.substring(1))) {

                            if (next.substring(0, 1).equals("0")) {
                                try {
                                    myFile.append("1" + next.substring(1) + "\r\n");
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                            } else if (next.substring(0, 1).equals("1")) {
                                try {
                                    myFile.append("0" + next.substring(1) + "\r\n");
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                            }


                        } else {
                            try {
                                myFile.append(next + "\r\n");
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                    try {
                        myFile.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    sc.close();
                    File newOG = new File(username + "temp.txt");
                    newOG.renameTo(og);

                }


            });
            p.add(tempHolder);


        }




        //gives you a congrats message--you've completed X tasks!
        JButton submit = new JButton("submit");
        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int numberDone = 0;
                File myList = new File(username + ".txt");

                try {
                    Scanner sc = new Scanner(myList);
                    while(sc.hasNextLine()){
                        if(sc.nextLine().substring(0,1).equals("1")){
                            numberDone++;
                        }
                    }

                } catch (FileNotFoundException ex) {
                    ex.printStackTrace();
                }

                p.add(new JLabel("Congrats! You've completed " + numberDone + " task(s)"));
                p.validate();
                p.repaint();

            }
        });


        //used for activities you no longer want on list
        JButton delete = new JButton("delete task");
        JTextField userDelete = new JTextField(25);
        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                try {
                    File og = new File(username + ".txt");
                    Scanner sc = new Scanner(og);
                    FileWriter myFile = new FileWriter(username + "temp.txt", true);

                    while(sc.hasNextLine()){
                        String next = sc.nextLine();
                        if(!(next.substring(1).equals(userDelete.getText()))){
                            myFile.append(next + "\r\n");
                        }
                    }
                    myFile.close();
                    sc.close();
                   File newOG= new File(username + "temp.txt");
                   newOG.renameTo(og);


                    p.removeAll();
                    p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
                    p.validate();
                    populateList(p, username);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });



        //area to add to-do
        JTextField newTask = new JTextField(25);
        JButton addTask = new JButton("add task");
        addTask.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                FileWriter myWriter;
                try {
                    if(!newTask.equals("")) {
                        myWriter = new FileWriter(username + ".txt", true);
                        myWriter.append("0" + newTask.getText() + "\r\n");
                        myWriter.close();
                        p.removeAll();
                        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
                        populateList(p, username);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });


        p.add(submit);
        p.add(newTask);
        p.add(addTask);
        p.add(userDelete);
        p.add(delete);
        p.validate();
        p.repaint();

    }

}


